# Konoba Stafileo

**Pozdrav, dobro došli na stranicu Konobe Stafileo!**

Ova stranica je demo web projekt izrađen po uzoru na izgled konobe Trs, ali s izmjenama u imenu, kontakt podacima i sadržaju za potrebe brenda **Konoba Stafileo**.

## Sadržaj

- `index.html` – Glavna HTML stranica
- `css/style.css` – CSS stilovi za dizajn stranice
- `images/` – Mapa za slike (trenutno s demo slikama)
- `js/` – Mapa za JavaScript datoteke (trenutno prazna)

## Upute za korištenje

1. Preuzmite projekt (Download ZIP ili `git clone`)
2. Otvorite `index.html` u svom pregledniku
3. Zamijenite slike i tekstove po želji
4. Po želji postavite stranicu na GitHub Pages kako bi bila javno dostupna

## Kontakt

- **Email:** lovrebenzon@gmail.com
- **Telefon:** 099 201 2957
- **Lokacija:** Split, Trogir

---

Hvala na korištenju i živjeli!

